# Test download cradle
write-host -ForegroundColor Cyan "$(Get-Date -Format s) Download Cradle test success!`n"
