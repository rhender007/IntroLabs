#include <stdio.h>
#include <unistd.h>
#include "test.h"

int main() {
    printf("the cake is a lie\n");
    return 0;
}
