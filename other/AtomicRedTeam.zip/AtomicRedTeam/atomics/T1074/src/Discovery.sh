#!/bin/

curl ifconfig.me
ifconfig
whoami
pwd
ls -lhart /Users/
ls /Applications/
ls /Library/
crontab -l
at -l
netstat -an | grep -i listen
netstat -an | grep -i established
arp -a
ps aux
