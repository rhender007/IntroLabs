## Application Compatibility Shims

All Files Contained in .Zip.

Otherwise you can roll your own.

##### This Shim Injects a DLL named AtomicTest.DLL from C:\Tools into an Application named AtomicTest.exe
##### Specifically with an Original_FileName and Internal_Name of AtomicTest.exe
##### Easiest way to create that is to compile and use the C# Sample AtomicTest.cs
