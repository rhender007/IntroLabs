#include <stdio.h>
#include <unistd.h>
int main()
{
    printf("Hello\n");
    sleep(5);
    printf("Don't run random binaries!\n");
    return 0;
}
