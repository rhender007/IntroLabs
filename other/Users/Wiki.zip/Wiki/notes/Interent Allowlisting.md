---
title: Interent Allowlisting
created: '2020-06-16T16:55:19.776Z'
modified: '2020-06-16T16:55:49.445Z'
---

# Interent Allowlisting

`docker run -d  --name pihole -p 53:53/tcp -p 53:53/udp -p 80:80 -p 443:443 -e TZ="America/New_York" -v "$(pwd)/etc-pihole/:/etc/pihole/" -v "$(pwd)/etc-dnsmasq.d/:/etc/dnsmasq.d/" --dns=127.0.0.1 --dns=1.1.1.1 --restart=unless-stopped pihole/pihole:latest`
