---
attachments: [Clipboard_2020-06-12-09-20-32.png, Clipboard_2020-06-12-09-43-43.png, Clipboard_2020-06-12-09-43-49.png, Clipboard_2020-06-12-09-44-53.png, Clipboard_2020-06-12-09-46-25.png, Clipboard_2020-06-12-10-36-44.png, Clipboard_2020-06-12-10-38-20.png, Clipboard_2020-06-12-10-38-52.png, Clipboard_2020-06-12-10-41-51.png, Clipboard_2020-06-12-10-50-32.png, Clipboard_2020-06-12-11-45-41.png, Clipboard_2020-06-12-11-48-24.png, Clipboard_2020-07-09-14-57-40.png, Clipboard_2020-07-09-14-58-51.png]
title: Password Cracking
created: '2020-06-12T15:18:49.730Z'
modified: '2020-07-09T20:58:51.201Z'
---

# Password Cracking

In this lab we will be getting started with the fundamentals of password cracking.  We will be using Hashcat to do this.

To start, we will be working with the Command Prompt in Windows Terminal.   This is on your desktop and can be opened by right-clicking it and selecting Run as administrator:


![](@attachment/Clipboard_2020-06-12-10-36-44.png)

When you get the pop up select Yes.

Next, to open a Command Prompt Window, select the Down Carrot ![](@attachment/Clipboard_2020-06-12-10-38-20.png) and then select Command Prompt.

![](@attachment/Clipboard_2020-06-12-10-38-52.png)

Next, we need to navigate to the hashcat directory.

C:\Users\adhd>`cd \tools\hashcat-4.1.0\`

![](@attachment/Clipboard_2020-06-12-10-41-51.png)

Now, lets crack some NT hashes.  These are the hashes that almost all modern Windows systems store these days.  Older systems may store LANMAN, but that is very rare.

C:\Tools\hascat-4.1.0>`hashcat64.exe -a 0 -m 1000 -r rules\Incisive-leetspeak.rule sam.txt password.lst`

When done it should look like this:

![](@attachment/Clipboard_2020-07-09-14-57-40.png)

Finally, let’s try and crack some MD5 hashes

C:\Tools\hascat-4.1.0>`hashcat64.exe -a 0 -m 0 -r rules\Incisive-leetspeak.rule md5.txt password.lst`

When done, it should look like this:

![](@attachment/Clipboard_2020-07-09-14-58-51.png)











