---
attachments: [Clipboard_2020-06-16-10-26-22.png, Clipboard_2020-06-16-10-37-09.png, Clipboard_2020-06-16-10-38-16.png, Clipboard_2020-06-16-10-39-16.png, Clipboard_2020-07-09-15-06-52.png]
title: Password Spray
created: '2020-06-15T16:49:35.144Z'
modified: '2020-07-09T21:06:52.907Z'
---

# Password Spray

Let's get started by opening a Terminal as Administrator

![](@attachment/Clipboard_2020-06-12-10-36-44.png)

Now, let's open a command Prompt:
![](@attachment/Clipboard_2020-06-16-09-53-18.png)

C:\Windows\system32> `cd \tools`

C:\Tools> `200-user-gen.bat`

It should look like this:

![](@attachment/Clipboard_2020-06-16-10-26-22.png)

Now, we will need to start PowerShell to run LocalPasswordSpray


C:\Tools> `powershell`

PS C:\Tools> `Set-ExecutionPolicy Unrestricted`

PS C:\Tools> `Import-Module .\LocalPasswordSpray.ps1`

It should look like this:

![](@attachment/Clipboard_2020-06-16-10-37-09.png)

Now, let’s try some password spraying against the local system!


PS C:\Tools> `Invoke-LocalPasswordSpray -Password Winter2020`

It should look like this:

![](@attachment/Clipboard_2020-07-09-15-06-52.png)

Now we need to clean up and make sure the system is ready for the rest of the labs:

PS C:\Tools> `exit`

C:\Tools> `user-remove.bat`

![](@attachment/Clipboard_2020-06-16-10-39-16.png)




